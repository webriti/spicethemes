<?php
if(is_admin()){
	require ST_TEMPLATE_DIR . '/admin/inc/class-spicethemes-about-page.php';
}

require ST_TEMPLATE_DIR . '/admin/inc/plugin-include-control.php';
require ST_TEMPLATE_DIR . '/admin/inc/include-companion.php';


