﻿=== Stacy ===

Contributors: spicethemes
Requires at least: 4.7
Tested up to: 5.0.2
Stable tag: 1.2.5.3

Multi-purpose WordPress theme

== Description ==

Stacy is a responsive, multi-purpose WordPress theme. It’s flexible and suitable for agencies, blogs, businesses, finance, accounting, consulting, corporations, or portfolios. Customization is easy and straight-forward, with options provided that allow you to setup your site to perfectly fit your desired online presence. For more details, visit this link https://wordpress.org/themes/spicepress/. We hope you will find the Stacy theme useful.


SpicePress WordPress Theme, Copyright 2018 SpiceThemes
SpicePress  is distributed under the terms of the GNU General Public License v2

Stacy Theme is the child theme of SpicePress, Copyright 2018 SpiceThemes
Stacy Theme is distributed under the terms of the GNU General Public License v2 


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.0 ==
1. Released

= 1.2.5.3 ==
1. Update Screenshot

== Screenshot Images ==

* All images are licensed under [CC0]
https://www.pexels.com/photo/two-macbook-pro-beside-gray-bowl-705675/