<?php
if(is_admin()){
	require STACY_ST_TEMPLATE_DIR . '/admin/inc/class-spicethemes-about-page.php';
}

require STACY_ST_TEMPLATE_DIR . '/admin/inc/plugin-include-control.php';
require STACY_ST_TEMPLATE_DIR . '/admin/inc/include-companion.php';


